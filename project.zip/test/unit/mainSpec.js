
// TODO: write some tests...

describe("Some tests", function() {
    it("should be true", function() {
        expect(true).toBe(true);
    });
});
